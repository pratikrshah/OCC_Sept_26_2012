﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;

namespace OCC_New_Approach
{
    public class RuleViewModel
    {
        #region Feilds
        private ObservableCollection<RuleModel> _rules;
        public myCommand ReturnToEditCommand { get; set; }
        public myCommand SendAsIsCommand { get; set; }
        #endregion

        #region Properties
        public ObservableCollection<RuleModel> rules
        {
            get
            {
                return _rules;
            }
            set
            {
                _rules = value;
            }
        }
        #endregion

        #region Constructor
        public RuleViewModel()
        {
            #region Populate the rule collection
            _rules = new ObservableCollection<RuleModel>()
            {
                    #region Populating Rule 1
                    new RuleModel()
                    {
                        ruleDetails = new Rule()
                        {
                            ruleName = 400,
                            ruleDescription = "External Recipients Rule",
                            blockType = blockType.SoftBlock
                        },
                        //ruleDerievedDetails = new RuleDerieved()
                        //{

                        //    blockImage = "/Resource/Images/" + blockType + ".png";
                        //}
                        
                    }
                    #endregion

                    #region Populating Rule 2
                    #endregion
            };
            #endregion

            ReturnToEditCommand = new myCommand(myReturnToEditCommandExecute, myCanReturnToEditCommandExecute);
            SendAsIsCommand = new myCommand(mySendAsIsCommandExecute, myCanSendAsIsCommandExecute);
        }
        #endregion

        private void myReturnToEditCommandExecute(object parameter)
        {

        }

        private bool myCanReturnToEditCommandExecute(object parameter)
        {
            return true;
        }

        private void mySendAsIsCommandExecute(object parameter)
        {

        }

        private bool myCanSendAsIsCommandExecute(object parameter)
        {
            return true;
        }
    }
}
